# -*- coding: utf-8 -*-
# Python 3

def main():
    from xstream import parseUrl
    from resources.lib.tools import infoDialog
    from os.path import join
    import sys
    import platform
    import os

    from resources.lib.config import cConfig
    from resources.lib.logger import logger
    from xbmcvfs import translatePath

    _addonPath_ = translatePath(cConfig().getAddonInfo('path'))
    sys.path.append(join(_addonPath_, 'resources', 'lib'))
    sys.path.append(join(_addonPath_, 'resources', 'lib', 'gui'))
    sys.path.append(join(_addonPath_, 'resources', 'lib', 'handler'))
    sys.path.append(join(_addonPath_, 'resources', 'art', 'sites'))
    sys.path.append(join(_addonPath_, 'resources', 'art'))
    sys.path.append(join(_addonPath_, 'sites'))    
    
    logger.debug('Start xStream Log, Version %s' % cConfig().getAddonInfo('version'))
    logger.debug('Python-Version: %s' % platform.python_version())

    try:
        parseUrl()
    except Exception as e:
        if str(e) == 'UserAborted':
            logger.debug('User aborted list creation');
        else:
            import traceback
            import xbmcgui
            logger.error(traceback.format_exc())
            value = (str(e.__class__.__name__) + ' : ' + str(e), str(traceback.format_exc().splitlines()[-3].split('addons')[-1]))
            dialog = xbmcgui.Dialog().ok(cConfig().getLocalizedString(257), str(value))

if __name__ == "__main__":
    main()
